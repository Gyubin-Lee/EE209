#ifndef PIPE
#define PIPE

void pipeline(char ***cmd, char *IN, char *OUT);

#endif